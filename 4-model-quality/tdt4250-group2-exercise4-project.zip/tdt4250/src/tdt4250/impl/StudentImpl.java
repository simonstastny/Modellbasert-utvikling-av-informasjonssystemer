/**
 */
package tdt4250.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import tdt4250.Answer;
import tdt4250.Course;
import tdt4250.Student;
import tdt4250.Tdt4250Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Student</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link tdt4250.impl.StudentImpl#getAttends <em>Attends</em>}</li>
 *   <li>{@link tdt4250.impl.StudentImpl#getSubmit <em>Submit</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StudentImpl extends PersonImpl implements Student {
	/**
	 * The cached value of the '{@link #getAttends() <em>Attends</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttends()
	 * @generated
	 * @ordered
	 */
	protected EList<Course> attends;

	/**
	 * The cached value of the '{@link #getSubmit() <em>Submit</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubmit()
	 * @generated
	 * @ordered
	 */
	protected EList<Answer> submit;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StudentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Tdt4250Package.Literals.STUDENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Course> getAttends() {
		if (attends == null) {
			attends = new EObjectWithInverseResolvingEList.ManyInverse<Course>(Course.class, this, Tdt4250Package.STUDENT__ATTENDS, Tdt4250Package.COURSE__IS_ATTENDED);
		}
		return attends;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Answer> getSubmit() {
		if (submit == null) {
			submit = new EObjectResolvingEList<Answer>(Answer.class, this, Tdt4250Package.STUDENT__SUBMIT);
		}
		return submit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Tdt4250Package.STUDENT__ATTENDS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getAttends()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Tdt4250Package.STUDENT__ATTENDS:
				return ((InternalEList<?>)getAttends()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Tdt4250Package.STUDENT__ATTENDS:
				return getAttends();
			case Tdt4250Package.STUDENT__SUBMIT:
				return getSubmit();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Tdt4250Package.STUDENT__ATTENDS:
				getAttends().clear();
				getAttends().addAll((Collection<? extends Course>)newValue);
				return;
			case Tdt4250Package.STUDENT__SUBMIT:
				getSubmit().clear();
				getSubmit().addAll((Collection<? extends Answer>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Tdt4250Package.STUDENT__ATTENDS:
				getAttends().clear();
				return;
			case Tdt4250Package.STUDENT__SUBMIT:
				getSubmit().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Tdt4250Package.STUDENT__ATTENDS:
				return attends != null && !attends.isEmpty();
			case Tdt4250Package.STUDENT__SUBMIT:
				return submit != null && !submit.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //StudentImpl
