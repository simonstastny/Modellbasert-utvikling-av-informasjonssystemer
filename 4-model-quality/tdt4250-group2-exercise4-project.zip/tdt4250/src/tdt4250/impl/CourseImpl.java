/**
 */
package tdt4250.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import tdt4250.Assigment;
import tdt4250.Course;
import tdt4250.Student;
import tdt4250.Tdt4250Package;
import tdt4250.Teacher;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Course</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link tdt4250.impl.CourseImpl#getID <em>ID</em>}</li>
 *   <li>{@link tdt4250.impl.CourseImpl#getCredit <em>Credit</em>}</li>
 *   <li>{@link tdt4250.impl.CourseImpl#getName <em>Name</em>}</li>
 *   <li>{@link tdt4250.impl.CourseImpl#getHas <em>Has</em>}</li>
 *   <li>{@link tdt4250.impl.CourseImpl#getIsAttended <em>Is Attended</em>}</li>
 *   <li>{@link tdt4250.impl.CourseImpl#getIsCoordinated <em>Is Coordinated</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CourseImpl extends EObjectImpl implements Course {
	/**
	 * The default value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected int id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getCredit() <em>Credit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCredit()
	 * @generated
	 * @ordered
	 */
	protected static final int CREDIT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCredit() <em>Credit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCredit()
	 * @generated
	 * @ordered
	 */
	protected int credit = CREDIT_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHas() <em>Has</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHas()
	 * @generated
	 * @ordered
	 */
	protected EList<Assigment> has;

	/**
	 * The cached value of the '{@link #getIsAttended() <em>Is Attended</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsAttended()
	 * @generated
	 * @ordered
	 */
	protected EList<Student> isAttended;

	/**
	 * The cached value of the '{@link #getIsCoordinated() <em>Is Coordinated</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsCoordinated()
	 * @generated
	 * @ordered
	 */
	protected EList<Teacher> isCoordinated;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CourseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Tdt4250Package.Literals.COURSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getID() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setID(int newID) {
		int oldID = id;
		id = newID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Tdt4250Package.COURSE__ID, oldID, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCredit() {
		return credit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCredit(int newCredit) {
		int oldCredit = credit;
		credit = newCredit;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Tdt4250Package.COURSE__CREDIT, oldCredit, credit));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Tdt4250Package.COURSE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Assigment> getHas() {
		if (has == null) {
			has = new EObjectContainmentEList<Assigment>(Assigment.class, this, Tdt4250Package.COURSE__HAS);
		}
		return has;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Student> getIsAttended() {
		if (isAttended == null) {
			isAttended = new EObjectWithInverseResolvingEList.ManyInverse<Student>(Student.class, this, Tdt4250Package.COURSE__IS_ATTENDED, Tdt4250Package.STUDENT__ATTENDS);
		}
		return isAttended;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Teacher> getIsCoordinated() {
		if (isCoordinated == null) {
			isCoordinated = new EObjectWithInverseResolvingEList.ManyInverse<Teacher>(Teacher.class, this, Tdt4250Package.COURSE__IS_COORDINATED, Tdt4250Package.TEACHER__COORDINATES);
		}
		return isCoordinated;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Tdt4250Package.COURSE__IS_ATTENDED:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getIsAttended()).basicAdd(otherEnd, msgs);
			case Tdt4250Package.COURSE__IS_COORDINATED:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getIsCoordinated()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Tdt4250Package.COURSE__HAS:
				return ((InternalEList<?>)getHas()).basicRemove(otherEnd, msgs);
			case Tdt4250Package.COURSE__IS_ATTENDED:
				return ((InternalEList<?>)getIsAttended()).basicRemove(otherEnd, msgs);
			case Tdt4250Package.COURSE__IS_COORDINATED:
				return ((InternalEList<?>)getIsCoordinated()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Tdt4250Package.COURSE__ID:
				return getID();
			case Tdt4250Package.COURSE__CREDIT:
				return getCredit();
			case Tdt4250Package.COURSE__NAME:
				return getName();
			case Tdt4250Package.COURSE__HAS:
				return getHas();
			case Tdt4250Package.COURSE__IS_ATTENDED:
				return getIsAttended();
			case Tdt4250Package.COURSE__IS_COORDINATED:
				return getIsCoordinated();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Tdt4250Package.COURSE__ID:
				setID((Integer)newValue);
				return;
			case Tdt4250Package.COURSE__CREDIT:
				setCredit((Integer)newValue);
				return;
			case Tdt4250Package.COURSE__NAME:
				setName((String)newValue);
				return;
			case Tdt4250Package.COURSE__HAS:
				getHas().clear();
				getHas().addAll((Collection<? extends Assigment>)newValue);
				return;
			case Tdt4250Package.COURSE__IS_ATTENDED:
				getIsAttended().clear();
				getIsAttended().addAll((Collection<? extends Student>)newValue);
				return;
			case Tdt4250Package.COURSE__IS_COORDINATED:
				getIsCoordinated().clear();
				getIsCoordinated().addAll((Collection<? extends Teacher>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Tdt4250Package.COURSE__ID:
				setID(ID_EDEFAULT);
				return;
			case Tdt4250Package.COURSE__CREDIT:
				setCredit(CREDIT_EDEFAULT);
				return;
			case Tdt4250Package.COURSE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case Tdt4250Package.COURSE__HAS:
				getHas().clear();
				return;
			case Tdt4250Package.COURSE__IS_ATTENDED:
				getIsAttended().clear();
				return;
			case Tdt4250Package.COURSE__IS_COORDINATED:
				getIsCoordinated().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Tdt4250Package.COURSE__ID:
				return id != ID_EDEFAULT;
			case Tdt4250Package.COURSE__CREDIT:
				return credit != CREDIT_EDEFAULT;
			case Tdt4250Package.COURSE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case Tdt4250Package.COURSE__HAS:
				return has != null && !has.isEmpty();
			case Tdt4250Package.COURSE__IS_ATTENDED:
				return isAttended != null && !isAttended.isEmpty();
			case Tdt4250Package.COURSE__IS_COORDINATED:
				return isCoordinated != null && !isCoordinated.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ID: ");
		result.append(id);
		result.append(", credit: ");
		result.append(credit);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //CourseImpl
