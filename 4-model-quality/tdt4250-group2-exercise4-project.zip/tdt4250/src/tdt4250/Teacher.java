/**
 */
package tdt4250;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Teacher</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link tdt4250.Teacher#getRole <em>Role</em>}</li>
 *   <li>{@link tdt4250.Teacher#getCoordinates <em>Coordinates</em>}</li>
 * </ul>
 * </p>
 *
 * @see tdt4250.Tdt4250Package#getTeacher()
 * @model
 * @generated
 */
public interface Teacher extends Person {
	/**
	 * Returns the value of the '<em><b>Role</b></em>' attribute.
	 * The literals are from the enumeration {@link tdt4250.ResponsibilityRole}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Role</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role</em>' attribute.
	 * @see tdt4250.ResponsibilityRole
	 * @see #setRole(ResponsibilityRole)
	 * @see tdt4250.Tdt4250Package#getTeacher_Role()
	 * @model
	 * @generated
	 */
	ResponsibilityRole getRole();

	/**
	 * Sets the value of the '{@link tdt4250.Teacher#getRole <em>Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Role</em>' attribute.
	 * @see tdt4250.ResponsibilityRole
	 * @see #getRole()
	 * @generated
	 */
	void setRole(ResponsibilityRole value);

	/**
	 * Returns the value of the '<em><b>Coordinates</b></em>' reference list.
	 * The list contents are of type {@link tdt4250.Course}.
	 * It is bidirectional and its opposite is '{@link tdt4250.Course#getIsCoordinated <em>Is Coordinated</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Coordinates</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Coordinates</em>' reference list.
	 * @see tdt4250.Tdt4250Package#getTeacher_Coordinates()
	 * @see tdt4250.Course#getIsCoordinated
	 * @model opposite="isCoordinated"
	 * @generated
	 */
	EList<Course> getCoordinates();

} // Teacher
