/**
 */
package tdt4250;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Course</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link tdt4250.Course#getID <em>ID</em>}</li>
 *   <li>{@link tdt4250.Course#getCredit <em>Credit</em>}</li>
 *   <li>{@link tdt4250.Course#getName <em>Name</em>}</li>
 *   <li>{@link tdt4250.Course#getHas <em>Has</em>}</li>
 *   <li>{@link tdt4250.Course#getIsAttended <em>Is Attended</em>}</li>
 *   <li>{@link tdt4250.Course#getIsCoordinated <em>Is Coordinated</em>}</li>
 * </ul>
 * </p>
 *
 * @see tdt4250.Tdt4250Package#getCourse()
 * @model
 * @generated
 */
public interface Course extends EObject {
	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(int)
	 * @see tdt4250.Tdt4250Package#getCourse_ID()
	 * @model
	 * @generated
	 */
	int getID();

	/**
	 * Sets the value of the '{@link tdt4250.Course#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(int value);

	/**
	 * Returns the value of the '<em><b>Credit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Credit</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Credit</em>' attribute.
	 * @see #setCredit(int)
	 * @see tdt4250.Tdt4250Package#getCourse_Credit()
	 * @model
	 * @generated
	 */
	int getCredit();

	/**
	 * Sets the value of the '{@link tdt4250.Course#getCredit <em>Credit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Credit</em>' attribute.
	 * @see #getCredit()
	 * @generated
	 */
	void setCredit(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see tdt4250.Tdt4250Package#getCourse_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link tdt4250.Course#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Has</b></em>' containment reference list.
	 * The list contents are of type {@link tdt4250.Assigment}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Has</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has</em>' containment reference list.
	 * @see tdt4250.Tdt4250Package#getCourse_Has()
	 * @model containment="true"
	 * @generated
	 */
	EList<Assigment> getHas();

	/**
	 * Returns the value of the '<em><b>Is Attended</b></em>' reference list.
	 * The list contents are of type {@link tdt4250.Student}.
	 * It is bidirectional and its opposite is '{@link tdt4250.Student#getAttends <em>Attends</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Attended</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Attended</em>' reference list.
	 * @see tdt4250.Tdt4250Package#getCourse_IsAttended()
	 * @see tdt4250.Student#getAttends
	 * @model opposite="attends"
	 * @generated
	 */
	EList<Student> getIsAttended();

	/**
	 * Returns the value of the '<em><b>Is Coordinated</b></em>' reference list.
	 * The list contents are of type {@link tdt4250.Teacher}.
	 * It is bidirectional and its opposite is '{@link tdt4250.Teacher#getCoordinates <em>Coordinates</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Coordinated</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Coordinated</em>' reference list.
	 * @see tdt4250.Tdt4250Package#getCourse_IsCoordinated()
	 * @see tdt4250.Teacher#getCoordinates
	 * @model opposite="coordinates"
	 * @generated
	 */
	EList<Teacher> getIsCoordinated();

} // Course
