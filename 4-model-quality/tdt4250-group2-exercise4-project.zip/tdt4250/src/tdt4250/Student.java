/**
 */
package tdt4250;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Student</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link tdt4250.Student#getAttends <em>Attends</em>}</li>
 *   <li>{@link tdt4250.Student#getSubmit <em>Submit</em>}</li>
 * </ul>
 * </p>
 *
 * @see tdt4250.Tdt4250Package#getStudent()
 * @model
 * @generated
 */
public interface Student extends Person {
	/**
	 * Returns the value of the '<em><b>Attends</b></em>' reference list.
	 * The list contents are of type {@link tdt4250.Course}.
	 * It is bidirectional and its opposite is '{@link tdt4250.Course#getIsAttended <em>Is Attended</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attends</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attends</em>' reference list.
	 * @see tdt4250.Tdt4250Package#getStudent_Attends()
	 * @see tdt4250.Course#getIsAttended
	 * @model opposite="isAttended"
	 * @generated
	 */
	EList<Course> getAttends();

	/**
	 * Returns the value of the '<em><b>Submit</b></em>' reference list.
	 * The list contents are of type {@link tdt4250.Answer}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Submit</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Submit</em>' reference list.
	 * @see tdt4250.Tdt4250Package#getStudent_Submit()
	 * @model
	 * @generated
	 */
	EList<Answer> getSubmit();

} // Student
